import { NextResponse } from "next/server"



export const PUT = ()=>{
    return NextResponse.json( {

    })
    
}