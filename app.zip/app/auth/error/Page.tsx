import React from 'react'

const ErrorAuthPage = () => {
  return (
    <div>ErrorAuthPage</div>
  )
}

export default ErrorAuthPage