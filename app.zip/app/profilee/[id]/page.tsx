"use client"

import React from 'react'

// get search params

const UserPage = ({
    params,
  }: {
    params: {
      id: number;
    };
  }) => {

  return (
    <div>

    </div>
  )
}

export default UserPage