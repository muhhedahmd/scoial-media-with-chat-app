"use client"
import React from 'react'
const Messages = ({changes} : {
    changes: any
}) => {
  return (
    <div>Messages</div>
  )
}

export default Messages