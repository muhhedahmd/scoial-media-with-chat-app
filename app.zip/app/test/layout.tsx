


export default  function Home({children} : {
  children: React.ReactNode
}) {


  // const session = await getServerSession(authOptions)
  // if(!session?.user ) { 
  //   return <div>Not logged in</div>
  // }

  
          

  
          
  
  // .eq('chatId', 1);



  return (

    <div className="">
      {/* <h1 className="text-2xl font-bold mb-4">Supabase Realtime Next.js Example</h1> */}
{children}

   

           

    </div>
  )
}


// {


// }